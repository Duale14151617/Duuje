# ARMY HQ: installable app (PWA) files

Everything below is relative to the ROOT of your repository (the folder that contains `frontend/`, `backend/`, `docs/`, `deploy/`).
The `files/` folder here mirrors that structure, so you can copy it over your repo root.

## Option A: copy the files (simplest)
Copy the contents of `files/` into your repository root and choose "Replace" when asked.
WARNING: this overwrites the 11 existing files listed under B. If you changed those files yourself since you sent me the project, use Option B.

## Option B: apply the patch (keeps your own changes)
From the repository root:
    git apply --check pwa.patch      # dry run, changes nothing
    git apply pwa.patch              # applies the text changes + adds the new text files
Then copy ONLY the three icon pictures (a patch cannot carry images):
    files/frontend/public/icon-192.png
    files/frontend/public/icon-512.png
    files/frontend/public/icon-maskable-512.png
  -> into frontend/public/

## A. NEW files (add these)
| File | Goes to |
|---|---|
| manifest.webmanifest | frontend/public/ |
| sw.js (service worker) | frontend/public/ |
| offline.html, offline.css, offline.js | frontend/public/ |
| icon-192.png, icon-512.png, icon-maskable-512.png | frontend/public/ |
| install.tsx | frontend/src/pwa/  (create the folder `pwa`) |
| PWA.md | docs/ |

## B. EXISTING files that were changed (replace, or use the patch)
| File | What changed |
|---|---|
| frontend/index.html | manifest link + app meta tags (the inline theme script is untouched, so your CSP hash stays valid) |
| frontend/src/main.tsx | registers the service worker |
| frontend/src/components/Icon.tsx | new `download` icon |
| frontend/src/components/Layout.tsx | Install button in the top bar |
| frontend/src/pages/Login.tsx | Install button on the sign-in page |
| frontend/src/i18n/en.ts and so.ts | 4 new `pwa.*` text keys each |
| frontend/scripts/netlify-dist.mjs | no-cache + manifest headers for Netlify |
| deploy/nginx.conf.example | no-cache rules for sw.js and the manifest |
| backend/config/settings.py | WhiteNoise: manifest MIME type + no-cache for the app files |
| CHANGELOG.md | one line |

## After copying
    cd frontend && npm ci && npm run typecheck && npm run build && npm test
    git add -A && git commit -m "Add installable app (PWA)" && git push
Deploy as usual. It must be served over HTTPS to be installable. Then open the site on a phone and tap "Install app".

## Rule of thumb for later
After you change any app file, bump VERSION in frontend/public/sw.js ("armyhq-v1" -> "armyhq-v2") so devices refresh their saved files.
