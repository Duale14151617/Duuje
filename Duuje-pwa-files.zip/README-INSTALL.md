# ARMY HQ: installable app (PWA) files

Everything below is relative to the ROOT of your repository (the folder that contains `frontend/`, `backend/`, `docs/`, `deploy/`).
The `files/` folder here mirrors that structure, so you can copy it over your repo root.

## Option A: copy the files (simplest)
Copy the contents of `files/` into your repository root and choose "Replace" when asked.
WARNING: this overwrites the 11 existing files listed under B (this overwrites 14 existing files including the 3 icon/favicon pictures). If you changed those files yourself since you sent me the project, use Option B.

## Option B: apply the patch (keeps your own changes)
From the repository root:
    git apply --check pwa.patch      # dry run, changes nothing
    git apply pwa.patch              # applies the text changes + adds the new text files
Then copy the picture files (a patch cannot carry images) from files/frontend/public/ into frontend/public/:
    icon-192.png, icon-512.png, icon-maskable-512.png, puntland-flag-logo.png   (new)
    apple-touch-icon.png, favicon-32.png, favicon.svg                           (replace the existing ones)

## A. NEW files (add these)
| File | Goes to |
|---|---|
| manifest.webmanifest | frontend/public/ |
| sw.js (service worker) | frontend/public/ |
| offline.html, offline.css, offline.js | frontend/public/ |
| icon-192.png, icon-512.png, icon-maskable-512.png | frontend/public/ |
| puntland-flag-logo.png (the flag logo used in the top bar, sidebar and offline page) | frontend/public/ |
| install.tsx | frontend/src/pwa/  (create the folder `pwa`) |
| PWA.md | docs/ |

## B. EXISTING files that were changed (replace, or use the patch)
| File | What changed |
|---|---|
| frontend/index.html | manifest link + app meta tags (the inline theme script is untouched, so your CSP hash stays valid) |
| frontend/src/main.tsx | registers the service worker |
| frontend/src/components/Icon.tsx | new `download` icon |
| frontend/src/components/Layout.tsx | Install button in the top bar; flag logo (puntland-flag-logo.png) replaces the old vector flag in the top bar and sidebar |
| frontend/src/pages/Login.tsx | Install button on the sign-in page |
| frontend/src/i18n/en.ts and so.ts | 4 new `pwa.*` text keys each |
| frontend/scripts/netlify-dist.mjs | no-cache + manifest headers for Netlify |
| deploy/nginx.conf.example | no-cache rules for sw.js and the manifest |
| backend/config/settings.py | WhiteNoise: manifest MIME type + no-cache for the app files |
| frontend/public/apple-touch-icon.png, favicon-32.png, favicon.svg | now made from the Puntland flag image |
| CHANGELOG.md | one line |

## After copying
    cd frontend && npm ci && npm run typecheck && npm run build && npm test
    git add -A && git commit -m "Add installable app (PWA)" && git push
Deploy as usual. It must be served over HTTPS to be installable. Then open the site on a phone and tap "Install app".

## Rule of thumb for later
After you change any app file, bump VERSION in frontend/public/sw.js ("armyhq-v1" -> "armyhq-v2") so devices refresh their saved files.
