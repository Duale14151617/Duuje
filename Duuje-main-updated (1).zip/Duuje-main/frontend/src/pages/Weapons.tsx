import { useEffect, useState, type FormEvent } from "react";
import { api } from "../api/client";
import type { Page } from "../api/types";
import { useAuth } from "../auth/AuthContext";
import { useFetch } from "../api/useFetch";
import { FilterBar } from "../components/FilterBar";
import { Chip, ErrorNotice, Field, Notice, PageHeader, Loading } from "../components/ui";
import { UnitPicker } from "../components/UnitPicker";
import { useI18n, type Key } from "../i18n";

interface Named { id?: string; code: string; name_en: string; name_so: string }
interface UnitB { id: string; code: string; name_en: string; name_so: string }
interface Person { id: string; full_name: string; service_number: string | null; status?: string; rank: Named; unit?: UnitB }
interface Custody {
  id: string; personnel: Person; issued_at: string; issued_by: string; authority_ref: string; issue_condition: string; issue_note: string;
  returned_at: string | null; returned_by: string; outcome: string; return_condition: string; return_note: string;
}
interface Weapon {
  id: string; serial: string; category: Named; org_unit: UnitB; issued_to_unit: UnitB | null; status: string; weapon_type: string;
  make_model: string; caliber: string; condition: string; version: number; custody: Custody | null;
  custody_history?: Custody[]; events?: { kind: string; note: string; actor: string; at: string; to_status: string }[];
}
interface Summary { total: number; in_custody: number; held_by_non_serving: number; by_type: Record<string, number>; by_status: Record<string, number> }

const CONDITIONS = ["serviceable", "needs_repair", "unserviceable"];
const tone = (c: string) => (c === "serviceable" ? "approved" : c === "unserviceable" ? "bad" : "draft");

/** Auditable weapon register: unique serial numbers, who holds each weapon, issue and return, condition and history. */
export function Weapons() {
  const { t, name } = useI18n();
  const { can } = useAuth();
  const canManage = can("weapons.manage");
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("");
  const [inCustody, setInCustody] = useState(false);
  const [page, setPage] = useState(1);
  const [openId, setOpenId] = useState<string | null>(null);
  const [registering, setRegistering] = useState(false);
  const summary = useFetch<Summary>("/weapons/summary/");
  const list = useFetch<Page<Weapon>>("/weapons/", { q, status, in_custody: inCustody ? 1 : undefined, page });
  const reloadAll = () => { list.reload(); summary.reload(); };

  return (
    <>
      <PageHeader title={t("weap.title")} actions={canManage && !registering ? <button type="button" onClick={() => setRegistering(true)}>{t("weap.register")}</button> : undefined} />
      <ErrorNotice error={summary.error ?? list.error} />
      {(summary.loading && !summary.data) || (list.loading && !list.data) ? <Loading /> : null}
      {summary.data && (
        <section className="card">
          <div className="stat"><span>{t("weap.total")}</span><b>{summary.data.total}</b></div>
          <div className="stat"><span>{t("weap.inCustody")}</span><b>{summary.data.in_custody}</b></div>
          {summary.data.held_by_non_serving > 0 && <Notice kind="error">{t("weap.nonServing", { n: summary.data.held_by_non_serving })}</Notice>}
          {Object.entries(summary.data.by_type).map(([k, n]) => <div className="stat" key={k}><span>{k}</span><b>{n}</b></div>)}
        </section>
      )}
      <FilterBar
        search={{ value: q, label: t("weap.search"), onChange: (v) => { setQ(v); setPage(1); } }}
        filters={[{ id: "status", label: t("pers.status"), value: status, onChange: (v) => { setStatus(v); setPage(1); },
                    options: ["in_stock", "issued", "maintenance", "missing", "lost", "retired"].map((s) => ({ value: s, label: t(`astatus.${s}` as Key) })) }]}
        advancedExtra={<label className="check"><input type="checkbox" checked={inCustody} onChange={(e) => { setInCustody(e.target.checked); setPage(1); }} /><span>{t("weap.onlyInCustody")}</span></label>}
        custom={[{ id: "custody", label: t("weap.onlyInCustody"), active: inCustody, onClear: () => { setInCustody(false); setPage(1); } }]}
        onReset={() => { setQ(""); setStatus(""); setInCustody(false); setPage(1); }} />
      {registering && <RegisterForm onDone={() => { setRegistering(false); reloadAll(); }} onCancel={() => setRegistering(false)} />}
      <ul className="list">
        {(list.data?.results ?? []).map((w) => (
          <li key={w.id} className="item">
            <button type="button" className="secondary" onClick={() => setOpenId(openId === w.id ? null : w.id)}>
              <b>{w.serial}</b> · {w.weapon_type}{w.make_model ? ` · ${w.make_model}` : ""}
            </button>
            <div className="row">
              <Chip tone={w.status === "in_stock" ? "approved" : "draft"}>{t(`astatus.${w.status}` as Key)}</Chip>
              <Chip tone={tone(w.condition)}>{t(`wcond.${w.condition}` as Key)}</Chip>
              <span className="muted">{name(w.issued_to_unit ?? w.org_unit)}</span>
            </div>
            {w.custody && <p className="muted">{t("weap.heldBy")}: {w.custody.personnel.rank.code} {w.custody.personnel.full_name} ({w.custody.personnel.service_number ?? "—"})</p>}
            {openId === w.id && <Detail id={w.id} canManage={canManage} onChanged={reloadAll} />}
          </li>
        ))}
      </ul>
      {list.data && (list.data.next || list.data.previous) && (
        <div className="row">
          <button type="button" className="secondary" disabled={!list.data.previous} onClick={() => setPage(page - 1)}>{t("common.previous")}</button>
          <button type="button" className="secondary" disabled={!list.data.next} onClick={() => setPage(page + 1)}>{t("common.next")}</button>
        </div>
      )}
    </>
  );
}

function RegisterForm({ onDone, onCancel }: { onDone: () => void; onCancel: () => void }) {
  const { t, name, lang } = useI18n();
  const cats = useFetch<{ results: (Named & { id: string })[] }>("/weapons/categories/");
  const [f, setF] = useState({ category: "", org_unit: "", serial: "", weapon_type: "", make_model: "", caliber: "", condition: "serviceable" });
  const [error, setError] = useState<unknown>(null);
  const catList = cats.data?.results ?? [];
  useEffect(() => { if (catList.length === 1 && !f.category) setF((x) => ({ ...x, category: catList[0].id })); }, [catList.length]); // eslint-disable-line react-hooks/exhaustive-deps
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });
  async function submit(e: FormEvent) {
    e.preventDefault(); setError(null);
    try { await api("/weapons/", { method: "POST", body: f }); onDone(); } catch (err) { setError(err); }
  }
  return (
    <form className="card" onSubmit={(e) => void submit(e)}>
      <ErrorNotice error={error ?? cats.error} />
      <Field label={t("weap.category")}>
        <select value={f.category} required disabled={catList.length === 0} onChange={set("category")}>
          <option value="">—</option>
          {catList.map((c) => <option key={c.id} value={c.id}>{name(c)}</option>)}
        </select>
      </Field>
      {cats.data && catList.length === 0 && (
        <Notice kind="error">
          {lang === "so"
            ? "Weli ma jirto qayb hub ah oo la ansixiyay. Fur Logistics → Categories, oo ka dhig qayb hub ah (tusaale Rifles, Pistols) mid la ansixiyay (waxaa sameyn kara isticmaale leh ogolaansho ansixinta qalabka xaddidan), ka dibna halkan dib u soo laadi."
            : "No approved weapon category exists yet. Open Logistics → Categories and approve a weapon category such as Rifles or Pistols (this needs a user with the restricted-approval permission), then reload this page."}
        </Notice>
      )}
      <UnitPicker label={t("weap.holdingUnit")} value={f.org_unit} required onChange={(id) => setF({ ...f, org_unit: id })} params={{ placeable: 1 }} />
      <Field label={t("weap.serial")}><input value={f.serial} required maxLength={64} autoCapitalize="characters" onChange={set("serial")} /></Field>
      <Field label={t("weap.type")}><input value={f.weapon_type} required maxLength={60} list="weapon-types" onChange={set("weapon_type")} /></Field>
      <datalist id="weapon-types">{["Assault rifle", "Rifle", "Pistol", "Submachine gun", "Light machine gun", "General-purpose machine gun", "Heavy machine gun", "Sniper rifle", "RPG launcher", "Grenade launcher", "Mortar"].map((x) => <option key={x} value={x} />)}</datalist>
      <Field label={t("weap.makeModel")}><input value={f.make_model} maxLength={120} onChange={set("make_model")} /></Field>
      <Field label={t("weap.caliber")}><input value={f.caliber} maxLength={40} list="weapon-calibers" onChange={set("caliber")} /><datalist id="weapon-calibers">{["5.56x45 mm", "7.62x39 mm", "7.62x51 mm", "7.62x54R mm", "9 mm", "12.7 mm", "14.5 mm", "60 mm", "82 mm"].map((x) => <option key={x} value={x} />)}</datalist></Field>
      <Field label={t("weap.condition")}>
        <select value={f.condition} onChange={set("condition")}>{CONDITIONS.map((c) => <option key={c} value={c}>{t(`wcond.${c}` as Key)}</option>)}</select>
      </Field>
      <div className="row"><button type="submit">{t("weap.register")}</button><button type="button" className="secondary" onClick={onCancel}>{t("common.cancel")}</button></div>
    </form>
  );
}

function Detail({ id, canManage, onChanged }: { id: string; canManage: boolean; onChanged: () => void }) {
  const { t, name } = useI18n();
  const w = useFetch<Weapon>(`/weapons/${id}/`);
  const [mode, setMode] = useState<"issue" | "return" | "condition" | null>(null);
  const [q, setQ] = useState("");
  const [person, setPerson] = useState("");
  const [condition, setCondition] = useState("serviceable");
  const [authority, setAuthority] = useState("");
  const [note, setNote] = useState("");
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);
  const unit = w.data ? (w.data.issued_to_unit ?? w.data.org_unit) : null;
  const people = useFetch<{ results: Person[] }>(mode === "issue" && unit ? "/weapons/people/" : null, { org_unit: unit?.id, q });
  if (!w.data) return w.error ? <ErrorNotice error={w.error} /> : <Loading />;
  const d = w.data;

  async function run(path: string, body: Record<string, unknown>) {
    setBusy(true); setError(null);
    try { await api(`/weapons/${id}/${path}/`, { method: "POST", body }); setMode(null); setPerson(""); setAuthority(""); setNote(""); w.reload(); onChanged(); }
    catch (err) { setError(err); } finally { setBusy(false); }
  }
  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (mode === "issue") void run("issue", { personnel: person, condition, authority_ref: authority, note, version: d.version });
    else if (mode === "return") void run("return", { condition, note, version: d.version });
    else void run("condition", { condition, note });
  };
  return (
    <div className="card">
      <ErrorNotice error={error} />
      <div className="stat"><span>{t("weap.serial")}</span><b>{d.serial}</b></div>
      <div className="stat"><span>{t("weap.caliber")}</span><b>{d.caliber || "—"}</b></div>
      <div className="stat"><span>{t("weap.holdingUnit")}</span><b>{name(d.org_unit)}</b></div>
      {canManage && mode === null && (
        <div className="row">
          {!d.custody && ["in_stock", "issued"].includes(d.status) && <button type="button" onClick={() => { setMode("issue"); setCondition(d.condition); }}>{t("weap.issue")}</button>}
          {d.custody && <button type="button" onClick={() => { setMode("return"); setCondition(d.condition); }}>{t("weap.return")}</button>}
          <button type="button" className="secondary" onClick={() => { setMode("condition"); setCondition(d.condition); }}>{t("weap.updateCondition")}</button>
        </div>
      )}
      {mode && (
        <form onSubmit={submit}>
          {mode === "issue" && (
            <>
              <input type="search" value={q} maxLength={60} placeholder={t("weap.findPerson")} aria-label={t("weap.findPerson")} onChange={(e) => setQ(e.target.value)} />
              <Field label={t("weap.holder")}>
                <select value={person} required onChange={(e) => setPerson(e.target.value)}>
                  <option value="">—</option>
                  {(people.data?.results ?? []).map((p) => <option key={p.id} value={p.id}>{p.rank.code} {p.full_name} ({p.service_number ?? "—"})</option>)}
                </select>
              </Field>
              <Field label={t("weap.authority")}><input value={authority} required maxLength={150} onChange={(e) => setAuthority(e.target.value)} /></Field>
            </>
          )}
          <Field label={t("weap.condition")}>
            <select value={condition} onChange={(e) => setCondition(e.target.value)}>{CONDITIONS.map((c) => <option key={c} value={c}>{t(`wcond.${c}` as Key)}</option>)}</select>
          </Field>
          <Field label={t("att.note")}><input value={note} maxLength={300} onChange={(e) => setNote(e.target.value)} /></Field>
          <div className="row">
            <button type="submit" disabled={busy || (mode === "issue" && !person)}>{t(mode === "issue" ? "weap.issue" : mode === "return" ? "weap.return" : "weap.updateCondition")}</button>
            <button type="button" className="secondary" onClick={() => setMode(null)}>{t("common.cancel")}</button>
          </div>
        </form>
      )}
      <h3>{t("weap.history")}</h3>
      {(d.custody_history ?? []).length === 0 && <p className="muted">{t("weap.noHistory")}</p>}
      <ul className="list">
        {(d.custody_history ?? []).map((c) => (
          <li key={c.id} className="item">
            <b>{c.personnel.rank.code} {c.personnel.full_name}</b> ({c.personnel.service_number ?? "—"})
            <p className="muted">{c.issued_at.slice(0, 10)} → {c.returned_at ? c.returned_at.slice(0, 10) : t("weap.stillHeld")} · {c.authority_ref} · {c.issued_by}</p>
            {c.outcome && <Chip tone={c.outcome === "returned" ? "approved" : "bad"}>{t(`weap.outcome.${c.outcome}` as Key)}</Chip>}
          </li>
        ))}
      </ul>
    </div>
  );
}
